package com.itqf.mapper;

import com.itqf.pojo.Equipments;
import com.itqf.pojo.Scene;

import java.util.List;

public interface EquipmentsMapper {
    public List<Equipments> findall();//全查
    int deleteByPrimaryKey(Integer equid);
    public List<Equipments> findequipbyid(int id);//根据id查下列设备
    int insert(Equipments record);

    int insertSelective(Equipments record);

    Equipments selectByPrimaryKey(Integer equid);

    int updateByPrimaryKeySelective(Equipments record);

    int updateByPrimaryKey(Equipments record);
}