package com.itqf.mapper;

import com.itqf.pojo.Equipments;
import com.itqf.pojo.Room;

import java.util.List;

public interface RoomMapper {
    int deleteByPrimaryKey(Integer roomid);
    public List<Room> findall();//全查
    public String findnamebyid(int id);//根据id查房间名字

    int insert(Room record);

    int insertSelective(Room record);

    Room selectByPrimaryKey(Integer roomid);

    int updateByPrimaryKeySelective(Room record);

    int updateByPrimaryKey(Room record);
}