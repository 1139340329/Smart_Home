package com.itqf.controller;

import com.itqf.pojo.Equipments;
import com.itqf.pojo.Room;
import com.itqf.pojo.Scene;
import com.itqf.service.EquipmenmtseService;
import com.itqf.service.RoomService;
import com.itqf.service.SceneService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import sun.awt.EventQueueItem;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class SceneController {
    @Resource
    private SceneService sceneService;
    @Resource
    private RoomService roomService;
    @Resource
    private EquipmenmtseService equipmenmtseService;
    @RequestMapping(method = RequestMethod.GET, value = "/firstpage/show")
    public Map findallscene(){
        List<Scene> findall = sceneService.findall();
        List<Equipments> findall1 = equipmenmtseService.findall();
        Map map=new HashMap();

        map.put("data",findall);

        map.put(" ",findall1);
        return map;
    }
}
