package com.itqf.controller;

import com.itqf.pojo.Equipments;
import com.itqf.pojo.Room;
import com.itqf.pojo.Scene;
import com.itqf.pojo.User;
import com.itqf.service.EquipmenmtseService;
import com.itqf.service.RoomService;
import com.itqf.service.SceneService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class RoomController {
    @Resource
    private RoomService roomService;
    @Resource
    private EquipmenmtseService equipmenmtseService;

    @RequestMapping(method = RequestMethod.GET, value = "/firstpage/room/show")
    public Map findall(int roomid) {
        Room room = roomService.selectByPrimaryKey(roomid);


        Map m = new HashMap();
        m.put("light", room.getLight());
        m.put("temperature", room.getTemperature());
        m.put("humidity", room.getHumidity());



        Map map = new HashMap();
        map.put("code",0);
        map.put("msg","成功");
        map.put("data", m);

        return map;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/room/show/equipment")
    public Map findallscene(int roomid){
        String findnamebyid = roomService.findnamebyid(roomid);
        List<Equipments> findequipbyid = equipmenmtseService.findequipbyid(roomid);

        Map data=new HashMap();
        data.put("roomname",findnamebyid);
        data.put("equipments",findequipbyid);
        Map map=new HashMap();
        map.put("data",data);
        return map;
    }
}
