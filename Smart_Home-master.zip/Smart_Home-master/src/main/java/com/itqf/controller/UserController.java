package com.itqf.controller;

import com.itqf.pojo.Tablelamp;
import com.itqf.pojo.User;
import com.itqf.service.UserService;
import com.itqf.util.DataView;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class UserController {
    @Resource
    private UserService userService;

    @RequestMapping(method = RequestMethod.POST, value = "/user/checkphone")
    public Map findall(String phone,String validatecode) {
        User user = userService.selectByPhone(phone);


        Map m = new HashMap();

        m.put("Nickname", user.getNickname());
        m.put("phone", user.getPhone());
        m.put("photo", user.getPhoto());
        m.put("eqnumber", user.getEqnumber());
        m.put("password", user.getPassword());
        m.put("userid", user.getUserid());

        Map map = new HashMap();
        map.put("msg","成功");
        map.put("code",0);

        map.put("data", m);

        return map;
    }


    @RequestMapping(method = RequestMethod.POST, value = "/user/login")
    public Map findall2(String phone,String password) {
        User user = userService.selectByPhonePassword(phone,password);


        Map m = new HashMap();
        m.put("userid", user.getUserid());
        m.put("Nickname", user.getNickname());
        m.put("phone", user.getPhone());
        m.put("photo", user.getPhoto());
        m.put("eqnumber", user.getEqnumber());
        m.put("password", user.getPassword());


        Map map = new HashMap();
        map.put("code",0);
        map.put("msg","成功");
        map.put("data", m);

        return map;
    }
}
