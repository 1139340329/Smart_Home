package com.itqf.pojo;

import java.util.List;

public class Room {
    private Integer roomid;

    private Integer light;

    private Integer temperature;

    private Integer humidity;

    private String roomimg;

    private Integer status;

    private String roomname;

    private Integer equipmentsid;
    private List<Equipments> geteuip;

    public List<Equipments> getGeteuip() {
        return geteuip;
    }

    public void setGeteuip(List<Equipments> geteuip) {
        this.geteuip = geteuip;
    }

    public Integer getRoomid() {
        return roomid;
    }

    public void setRoomid(Integer roomid) {
        this.roomid = roomid;
    }

    public Integer getLight() {
        return light;
    }

    public void setLight(Integer light) {
        this.light = light;
    }

    public Integer getTemperature() {
        return temperature;
    }

    public void setTemperature(Integer temperature) {
        this.temperature = temperature;
    }

    public Integer getHumidity() {
        return humidity;
    }

    public void setHumidity(Integer humidity) {
        this.humidity = humidity;
    }

    public String getRoomimg() {
        return roomimg;
    }

    public void setRoomimg(String roomimg) {
        this.roomimg = roomimg == null ? null : roomimg.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname == null ? null : roomname.trim();
    }

    public Integer getEquipmentsid() {
        return equipmentsid;
    }

    public void setEquipmentsid(Integer equipmentsid) {
        this.equipmentsid = equipmentsid;
    }
}