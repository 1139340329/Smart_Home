package com.itqf.pojo;

public class Equipments {
    private Integer equid;

    private String type;

    private String equname;

    private String equimg;

    private Integer status;

    private Integer temperature;
    private Room room;

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Integer getEquid() {
        return equid;
    }

    public void setEquid(Integer equid) {
        this.equid = equid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getEquname() {
        return equname;
    }

    public void setEquname(String equname) {
        this.equname = equname == null ? null : equname.trim();
    }

    public String getEquimg() {
        return equimg;
    }

    public void setEquimg(String equimg) {
        this.equimg = equimg == null ? null : equimg.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getTemperature() {
        return temperature;
    }

    public void setTemperature(Integer temperature) {
        this.temperature = temperature;
    }
}