package com.itqf.service.impl;

import com.itqf.mapper.SceneMapper;
import com.itqf.pojo.Scene;
import com.itqf.service.SceneService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SceneServiceImpl implements SceneService {
    @Resource
    private SceneMapper sceneMapper;
    @Override
    public List<Scene> findall() {
        List<Scene> findall = sceneMapper.findall();

        List list=new ArrayList();

        for (Scene scene : findall) {
            Map map=new HashMap();
            map.put("imgurl",scene.getImgurl());
            map.put("sceneid",scene.getSceneid());
            map.put("status",scene.getStatus());

            list.add(map);
        }
        return list;

    }



    @Override
    public int deleteByPrimaryKey(Integer sceneid) {
        return 0;
    }

    @Override
    public int insert(Scene record) {
        return 0;
    }

    @Override
    public int insertSelective(Scene record) {
        return 0;
    }

    @Override
    public Scene selectByPrimaryKey(Integer sceneid) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(Scene record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(Scene record) {
        return 0;
    }
}
