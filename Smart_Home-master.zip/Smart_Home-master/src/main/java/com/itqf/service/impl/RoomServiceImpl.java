package com.itqf.service.impl;

import com.itqf.mapper.RoomMapper;
import com.itqf.pojo.Room;
import com.itqf.service.RoomService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RoomServiceImpl implements RoomService {
    @Resource
    private RoomMapper roomMapper;
    @Override
    public int deleteByPrimaryKey(Integer roomid) {
        return 0;
    }

    @Override
    public List<Room> findall() {
        List<Room> findall = roomMapper.findall();

        List list=new ArrayList();

        for (Room room : findall) {
            Map map=new HashMap();
            map.put("roomid",room.getRoomid());
            map.put("roomimg",room.getRoomimg());
            map.put("status",room.getStatus());
            list.add(map);
        }
        return list;
    }

    @Override
    public String findnamebyid(int id) {
        return roomMapper.findnamebyid(id);
    }


    @Override
    public int insert(Room record) {
        return 0;
    }

    @Override
    public int insertSelective(Room record) {
        return 0;
    }

    @Override
    public Room selectByPrimaryKey(Integer roomid) {
        return roomMapper.selectByPrimaryKey(roomid);
    }

    @Override
    public int updateByPrimaryKeySelective(Room record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(Room record) {
        return 0;
    }
}
