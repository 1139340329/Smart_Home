package com.itqf.service;

import com.itqf.pojo.User;

public interface UserService {
    public User selectByPhone(String phone);//按手机号查询用户
    public User  selectByPhonePassword(String phone,String password);//按手机号和密码查询
    int deleteByPrimaryKey(Integer userid);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer userid);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);
}
