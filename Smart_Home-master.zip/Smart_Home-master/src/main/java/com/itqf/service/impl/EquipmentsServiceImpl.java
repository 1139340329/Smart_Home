package com.itqf.service.impl;

import com.itqf.mapper.EquipmentsMapper;
import com.itqf.pojo.Equipments;
import com.itqf.pojo.Room;
import com.itqf.pojo.Scene;
import com.itqf.service.EquipmenmtseService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EquipmentsServiceImpl implements EquipmenmtseService {
    @Resource
    private EquipmentsMapper equipmentsMapper;
    @Override
    public List<Equipments> findall() {
        List<Equipments> findall = equipmentsMapper.findall();

        List list=new ArrayList();

        for (Equipments equipments : findall) {
            Map map=new HashMap();
            map.put("equid",equipments.getEquid());
            map.put("equimg",equipments.getEquimg());
            map.put("status",equipments.getStatus());
            list.add(map);
        }
        return list;
    }

    @Override
    public List<Equipments> findequipbyid(int id) {
        return equipmentsMapper.findequipbyid(id);
    }

    @Override
    public int deleteByPrimaryKey(Integer equid) {
        return 0;
    }

    @Override
    public int insert(Equipments record) {
        return 0;
    }

    @Override
    public int insertSelective(Equipments record) {
        return 0;
    }

    @Override
    public Equipments selectByPrimaryKey(Integer equid) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(Equipments record) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(Equipments record) {
        return 0;
    }
}
