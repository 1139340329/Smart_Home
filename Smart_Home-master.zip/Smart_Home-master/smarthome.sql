/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50521
 Source Host           : localhost:3306
 Source Schema         : smarthome

 Target Server Type    : MySQL
 Target Server Version : 50521
 File Encoding         : 65001

 Date: 05/08/2019 15:47:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for equipments
-- ----------------------------
DROP TABLE IF EXISTS `equipments`;
CREATE TABLE `equipments`  (
  `equid` int(11) NOT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `equname` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `equimg` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  ` status` int(255) NULL DEFAULT NULL,
  `temperature` int(255) NULL DEFAULT NULL,
  PRIMARY KEY (`equid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of equipments
-- ----------------------------
INSERT INTO `equipments` VALUES (12, '空调', '空调', '图片路径', 1, 26);
INSERT INTO `equipments` VALUES (13, '灯', '灯', '路径', 0, 22);
INSERT INTO `equipments` VALUES (14, '电视', '电视', '路径', 1, 23);

-- ----------------------------
-- Table structure for equipmentsid_quipid
-- ----------------------------
DROP TABLE IF EXISTS `equipmentsid_quipid`;
CREATE TABLE `equipmentsid_quipid`  (
  `equipmentsid` int(255) NOT NULL,
  `quipid` int(255) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of equipmentsid_quipid
-- ----------------------------
INSERT INTO `equipmentsid_quipid` VALUES (1, 12);
INSERT INTO `equipmentsid_quipid` VALUES (2, 13);
INSERT INTO `equipmentsid_quipid` VALUES (3, 14);
INSERT INTO `equipmentsid_quipid` VALUES (1, 13);
INSERT INTO `equipmentsid_quipid` VALUES (1, 14);

-- ----------------------------
-- Table structure for room
-- ----------------------------
DROP TABLE IF EXISTS `room`;
CREATE TABLE `room`  (
  `roomid` int(11) NOT NULL,
  `light` int(255) NULL DEFAULT NULL,
  `temperature` int(255) NULL DEFAULT NULL,
  `humidity` int(255) NULL DEFAULT NULL,
  `roomimg` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `status` int(255) NULL DEFAULT NULL,
  `roomname` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `equipmentsid` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`roomid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of room
-- ----------------------------
INSERT INTO `room` VALUES (123, 79, 28, 20, 'xxx', 1, '客厅', 1);
INSERT INTO `room` VALUES (124, 80, 26, 21, 'xxx', 0, '厕所', 2);
INSERT INTO `room` VALUES (125, 87, 30, 22, 'xxx', 1, '厨房', 3);

-- ----------------------------
-- Table structure for scene
-- ----------------------------
DROP TABLE IF EXISTS `scene`;
CREATE TABLE `scene`  (
  `sceneid` int(11) NOT NULL AUTO_INCREMENT,
  `imgurl` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `status` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`sceneid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1114 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of scene
-- ----------------------------
INSERT INTO `scene` VALUES (1111, 'xxx', 1);
INSERT INTO `scene` VALUES (1112, 'xxx', 0);
INSERT INTO `scene` VALUES (1113, 'xxx', 1);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `Nickname` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `photo` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `eqnumber` int(11) NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`userid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '大左', '123456789', '1111', 2, '123456');
INSERT INTO `user` VALUES (2, '小米', '223456789', '2222', 3, '123456');
INSERT INTO `user` VALUES (3, '得到', '323456789', '3333', 8, '123456');
INSERT INTO `user` VALUES (4, '方法', '423456789', '4444', 9, '123456');

SET FOREIGN_KEY_CHECKS = 1;
